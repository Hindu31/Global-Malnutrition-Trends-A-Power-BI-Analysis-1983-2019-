# Finance Data Processing & Access Control Backend

A production-quality REST API backend for a finance dashboard system, built with **Node.js**, **Express**, and **SQLite** (via `better-sqlite3`).

---

## Tech Stack

| Layer        | Choice                          | Reason                                          |
|--------------|---------------------------------|-------------------------------------------------|
| Runtime      | Node.js 18+                     | Widely supported, async-friendly                |
| Framework    | Express 4                       | Minimal, well-understood, easy to reason about  |
| Database     | SQLite via `better-sqlite3`     | Zero-config, synchronous API, file-based        |
| Validation   | Zod                             | Schema-first, excellent error messages          |
| Auth         | JWT (`jsonwebtoken`) + bcrypt   | Stateless, standard, no external dependency     |
| Testing      | Jest + Supertest                | Integration tests against real HTTP layer       |
| Rate Limiting| `express-rate-limit`            | Protects endpoints from abuse                   |

---

## Project Structure

```
finance-backend/
├── src/
│   ├── app.js                  # Express app setup & route registration
│   ├── config/
│   │   ├── db.js               # SQLite connection, schema init
│   │   └── seed.js             # Default users + sample records
│   ├── middleware/
│   │   ├── auth.js             # JWT verify, requireRole, requireMinRole
│   │   └── errorHandler.js     # Central error handler, AppError class
│   ├── routes/
│   │   ├── auth.js             # POST /login, GET /me
│   │   ├── users.js            # CRUD for users (admin-gated)
│   │   ├── records.js          # CRUD for financial records
│   │   └── dashboard.js        # Analytics & summary endpoints
│   ├── services/
│   │   ├── authService.js      # Login logic
│   │   ├── userService.js      # User CRUD + business rules
│   │   ├── recordService.js    # Record CRUD + filter/pagination
│   │   └── dashboardService.js # Aggregation queries
│   └── utils/
│       ├── validators.js       # Zod schemas + validate() middleware
│       └── paginate.js         # Reusable pagination helper
├── tests/
│   ├── setup.js                # Global Jest setup (creates test DB + seeds)
│   ├── teardown.js             # Global Jest teardown (removes test DB)
│   └── api.test.js             # Integration tests for all endpoints
├── .env.example
├── .gitignore
├── jest.config.json
└── package.json
```

---

## Getting Started

### Prerequisites

- Node.js 18 or higher
- npm

### Installation

```bash
git clone <repository-url>
cd finance-backend
npm install
```

### Configuration

```bash
cp .env.example .env
# Edit .env if you want a custom PORT or JWT_SECRET
```

### Seed the Database

```bash
npm run seed
```

This creates three default users:

| Role    | Email                  | Password     |
|---------|------------------------|--------------|
| admin   | admin@finance.com      | Admin@123    |
| analyst | analyst@finance.com    | Analyst@123  |
| viewer  | viewer@finance.com     | Viewer@123   |

It also inserts 10 sample financial records.

### Start the Server

```bash
npm start          # production
npm run dev        # development with nodemon (auto-reload)
```

Server starts on `http://localhost:3000` (or your configured PORT).

### Run Tests

```bash
npm test
```

Tests use a separate isolated `data/test.db` that is created fresh before every run and deleted after.

---

## API Reference

All protected endpoints require:

```
Authorization: Bearer <token>
```

### Auth

#### `POST /api/auth/login`
**Public.** Returns a JWT token.

```json
// Request
{ "email": "admin@finance.com", "password": "Admin@123" }

// Response 200
{
  "success": true,
  "data": {
    "token": "eyJ...",
    "user": { "id": "...", "name": "Super Admin", "email": "...", "role": "admin" }
  }
}
```

#### `GET /api/auth/me`
**Protected.** Returns the currently authenticated user.

---

### Users `/api/users`

| Method | Path          | Role  | Description            |
|--------|---------------|-------|------------------------|
| GET    | `/`           | admin | List all users (paged) |
| GET    | `/:id`        | any*  | Get user by ID         |
| POST   | `/`           | admin | Create a user          |
| PATCH  | `/:id`        | admin | Update role/status     |
| DELETE | `/:id`        | admin | Delete a user          |

*Non-admins may only fetch their own profile.

**Create User body:**
```json
{ "name": "Jane Doe", "email": "jane@example.com", "password": "Secret@123", "role": "analyst" }
```

**Update User body (any subset):**
```json
{ "role": "viewer", "status": "inactive" }
```

---

### Financial Records `/api/records`

| Method | Path  | Min Role | Description                         |
|--------|-------|----------|-------------------------------------|
| GET    | `/`   | viewer   | List records (filtered & paginated) |
| GET    | `/:id`| viewer   | Get single record                   |
| POST   | `/`   | analyst  | Create a record                     |
| PATCH  | `/:id`| admin    | Update a record                     |
| DELETE | `/:id`| admin    | Soft-delete a record                |

**Create Record body:**
```json
{
  "amount": 5000,
  "type": "income",
  "category": "Freelance",
  "date": "2025-04-01",
  "notes": "Design project payment"
}
```

**GET /api/records — Query Parameters:**

| Param       | Type   | Description                       |
|-------------|--------|-----------------------------------|
| `type`      | string | `income` or `expense`             |
| `category`  | string | Partial match                     |
| `date_from` | string | YYYY-MM-DD                        |
| `date_to`   | string | YYYY-MM-DD                        |
| `page`      | number | Default 1                         |
| `limit`     | number | Default 20, max 100               |
| `sort_by`   | string | `date`, `amount`, `created_at`    |
| `sort_order`| string | `asc` or `desc` (default `desc`)  |

---

### Dashboard `/api/dashboard`

All dashboard endpoints require **analyst** or **admin** role.

| Endpoint                       | Description                              |
|-------------------------------|------------------------------------------|
| `GET /summary`                | Total income, expenses, net balance      |
| `GET /categories`             | Per-category totals (filterable)         |
| `GET /trends/monthly`         | Monthly income vs expense (by year)      |
| `GET /trends/weekly`          | Last 12 weeks income vs expense          |
| `GET /recent?limit=10`        | Most recent financial entries            |

**Summary example response:**
```json
{
  "success": true,
  "data": {
    "total_income": 115000,
    "total_expenses": 11700,
    "net_balance": 103300,
    "total_records": 10
  }
}
```

**Summary supports date filtering:**
```
GET /api/dashboard/summary?date_from=2025-03-01&date_to=2025-03-31
```

---

## Access Control Matrix

| Action                       | viewer | analyst | admin |
|-----------------------------|--------|---------|-------|
| Login                        | ✅     | ✅      | ✅    |
| View own profile             | ✅     | ✅      | ✅    |
| List/view financial records  | ✅     | ✅      | ✅    |
| Create financial record      | ❌     | ✅      | ✅    |
| Update financial record      | ❌     | ❌      | ✅    |
| Delete financial record      | ❌     | ❌      | ✅    |
| Access dashboard analytics   | ❌     | ✅      | ✅    |
| List all users               | ❌     | ❌      | ✅    |
| Create/update/delete users   | ❌     | ❌      | ✅    |

---

## Error Handling

All errors follow a consistent format:

```json
{ "error": "Descriptive error message" }
```

Validation errors (422) include field-level detail:

```json
{
  "error": "Validation failed",
  "details": [
    { "field": "amount", "message": "Amount must be positive" },
    { "field": "date",   "message": "Date must be YYYY-MM-DD" }
  ]
}
```

| Status | Meaning                          |
|--------|----------------------------------|
| 200    | Success                          |
| 201    | Resource created                 |
| 401    | Missing/invalid token            |
| 403    | Authenticated but insufficient role |
| 404    | Resource not found               |
| 409    | Conflict (e.g. duplicate email)  |
| 422    | Validation failed                |
| 429    | Rate limit exceeded              |
| 500    | Unexpected server error          |

---

## Design Decisions & Assumptions

1. **SQLite over PostgreSQL**: Chosen for zero-config local setup. The service layer is database-agnostic enough to swap in a different driver with minimal changes.

2. **Soft deletes for records**: Financial records are soft-deleted (`is_deleted = 1`) rather than hard-deleted. This preserves audit history. Users are hard-deleted since there's no audit requirement specified.

3. **Analyst can create records**: The assignment says analysts "can view records and access insights." I extended this slightly to allow record creation too, since analysts often need to log data. This is clearly documented and easy to restrict.

4. **Synchronous SQLite (`better-sqlite3`)**: The synchronous API is simpler to reason about in Express and avoids callback/promise complexity for a single-file DB.

5. **JWT expiry of 8 hours**: Reasonable for a dashboard session. No refresh token is implemented — out of scope for this assessment.

6. **Rate limiting**: 100 requests per 15 minutes per IP — a simple global limiter. Production systems would need per-route tuning.

7. **No soft delete on users**: Deleting a user is permanent. In a real system, you'd soft-delete to preserve record ownership history. The records table keeps `created_by` as a FK — if the user is deleted, those records would become orphaned. A production fix would be: soft-delete users or set `created_by` to a system placeholder on delete.

---

## Health Check

```
GET /health

→ { "status": "ok", "timestamp": "2025-04-01T10:00:00.000Z" }
```
