const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");
const { getDb } = require("../config/db");
const { signToken } = require("../middleware/auth");
const { AppError } = require("../middleware/errorHandler");

function login({ email, password }) {
  const db = getDb();
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || !bcrypt.compareSync(password, user.password)) {
    throw new AppError("Invalid email or password", 401);
  }
  if (user.status === "inactive") {
    throw new AppError("Account is inactive. Contact an administrator.", 403);
  }

  const token = signToken(user.id);
  return {
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  };
}

module.exports = { login };
