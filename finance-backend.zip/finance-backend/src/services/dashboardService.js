const { getDb } = require("../config/db");

function getSummary({ date_from, date_to } = {}) {
  const db = getDb();

  // Build optional date filter
  const conditions = ["is_deleted = 0"];
  const params = [];
  if (date_from) { conditions.push("date >= ?"); params.push(date_from); }
  if (date_to)   { conditions.push("date <= ?"); params.push(date_to); }
  const where = `WHERE ${conditions.join(" AND ")}`;

  const totals = db.prepare(`
    SELECT
      SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END) as total_income,
      SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expenses,
      COUNT(*) as total_records
    FROM financial_records ${where}
  `).get(...params);

  return {
    total_income:   totals.total_income   || 0,
    total_expenses: totals.total_expenses || 0,
    net_balance:    (totals.total_income || 0) - (totals.total_expenses || 0),
    total_records:  totals.total_records  || 0,
  };
}

function getCategoryBreakdown({ date_from, date_to, type } = {}) {
  const db = getDb();
  const conditions = ["is_deleted = 0"];
  const params = [];
  if (type)      { conditions.push("type = ?");     params.push(type); }
  if (date_from) { conditions.push("date >= ?");    params.push(date_from); }
  if (date_to)   { conditions.push("date <= ?");    params.push(date_to); }

  return db.prepare(`
    SELECT category, type, SUM(amount) as total, COUNT(*) as count
    FROM financial_records
    WHERE ${conditions.join(" AND ")}
    GROUP BY category, type
    ORDER BY total DESC
  `).all(...params);
}

function getMonthlyTrends({ year, months = 12 } = {}) {
  const db = getDb();
  const targetYear = year || new Date().getFullYear();

  return db.prepare(`
    SELECT
      strftime('%Y-%m', date) as month,
      SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END) as income,
      SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as expenses,
      SUM(CASE WHEN type = 'income'  THEN amount ELSE -amount END) as net
    FROM financial_records
    WHERE is_deleted = 0
      AND strftime('%Y', date) = ?
    GROUP BY month
    ORDER BY month ASC
  `).all(String(targetYear));
}

function getRecentActivity(limit = 10) {
  return getDb().prepare(`
    SELECT r.id, r.amount, r.type, r.category, r.date, r.notes,
           u.name as created_by_name
    FROM financial_records r
    JOIN users u ON r.created_by = u.id
    WHERE r.is_deleted = 0
    ORDER BY r.created_at DESC
    LIMIT ?
  `).all(limit);
}

function getWeeklyTrends() {
  return getDb().prepare(`
    SELECT
      strftime('%Y-W%W', date) as week,
      SUM(CASE WHEN type = 'income'  THEN amount ELSE 0 END) as income,
      SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as expenses
    FROM financial_records
    WHERE is_deleted = 0
      AND date >= date('now', '-12 weeks')
    GROUP BY week
    ORDER BY week ASC
  `).all();
}

module.exports = {
  getSummary,
  getCategoryBreakdown,
  getMonthlyTrends,
  getRecentActivity,
  getWeeklyTrends,
};
