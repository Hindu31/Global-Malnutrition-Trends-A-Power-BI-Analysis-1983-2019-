const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");
const { getDb } = require("../config/db");
const { AppError } = require("../middleware/errorHandler");

const PUBLIC_FIELDS = "id, name, email, role, status, created_at, updated_at";

function listUsers({ page = 1, limit = 20 } = {}) {
  const db = getDb();
  const offset = (page - 1) * limit;
  const total = db.prepare("SELECT COUNT(*) as total FROM users").get().total;
  const users = db.prepare(
    `SELECT ${PUBLIC_FIELDS} FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?`
  ).all(limit, offset);

  return {
    data: users,
    pagination: {
      total, page, limit,
      total_pages: Math.ceil(total / limit),
      has_next: page * limit < total,
      has_prev: page > 1,
    },
  };
}

function getUserById(id) {
  const user = getDb()
    .prepare(`SELECT ${PUBLIC_FIELDS} FROM users WHERE id = ?`)
    .get(id);
  if (!user) throw new AppError("User not found", 404);
  return user;
}

function createUser({ name, email, password, role }) {
  const db = getDb();
  const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (exists) throw new AppError("Email already in use", 409);

  const id = uuidv4();
  const hash = bcrypt.hashSync(password, 10);
  db.prepare(`
    INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, ?)
  `).run(id, name, email, hash, role);

  return getUserById(id);
}

function updateUser(id, updates) {
  const db = getDb();
  const user = db.prepare("SELECT id FROM users WHERE id = ?").get(id);
  if (!user) throw new AppError("User not found", 404);

  const fields = [];
  const values = [];

  if (updates.name !== undefined)   { fields.push("name = ?");   values.push(updates.name); }
  if (updates.role !== undefined)   { fields.push("role = ?");   values.push(updates.role); }
  if (updates.status !== undefined) { fields.push("status = ?"); values.push(updates.status); }

  fields.push("updated_at = datetime('now')");
  values.push(id);

  db.prepare(`UPDATE users SET ${fields.join(", ")} WHERE id = ?`).run(...values);
  return getUserById(id);
}

function deleteUser(id, requesterId) {
  if (id === requesterId) throw new AppError("Cannot delete your own account", 400);
  const db = getDb();
  const user = db.prepare("SELECT id FROM users WHERE id = ?").get(id);
  if (!user) throw new AppError("User not found", 404);
  db.prepare("DELETE FROM users WHERE id = ?").run(id);
  return { message: "User deleted successfully" };
}

module.exports = { listUsers, getUserById, createUser, updateUser, deleteUser };
