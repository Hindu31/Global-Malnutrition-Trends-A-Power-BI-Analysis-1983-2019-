const { v4: uuidv4 } = require("uuid");
const { getDb } = require("../config/db");
const { AppError } = require("../middleware/errorHandler");

/**
 * Build a dynamic WHERE clause from filter params.
 * Returns { clause, params } where params is an array for positional binding.
 */
function buildFilters(filters) {
  const conditions = ["r.is_deleted = 0"];
  const params = [];

  if (filters.type)      { conditions.push("r.type = ?");     params.push(filters.type); }
  if (filters.category)  { conditions.push("r.category LIKE ?"); params.push(`%${filters.category}%`); }
  if (filters.date_from) { conditions.push("r.date >= ?");    params.push(filters.date_from); }
  if (filters.date_to)   { conditions.push("r.date <= ?");    params.push(filters.date_to); }

  return { clause: `WHERE ${conditions.join(" AND ")}`, params };
}

function listRecords(filters) {
  const db = getDb();
  const { clause, params } = buildFilters(filters);
  const { page, limit, sort_by, sort_order } = filters;

  const allowedSorts = { date: "r.date", amount: "r.amount", created_at: "r.created_at" };
  const orderCol = allowedSorts[sort_by] || "r.date";
  const order = sort_order === "asc" ? "ASC" : "DESC";

  const total = db.prepare(
    `SELECT COUNT(*) as total FROM financial_records r ${clause}`
  ).get(...params).total;

  const offset = (page - 1) * limit;
  const data = db.prepare(`
    SELECT r.*, u.name as created_by_name
    FROM financial_records r
    JOIN users u ON r.created_by = u.id
    ${clause}
    ORDER BY ${orderCol} ${order}
    LIMIT ? OFFSET ?
  `).all(...params, limit, offset);

  return {
    data,
    pagination: {
      total, page, limit,
      total_pages: Math.ceil(total / limit),
      has_next: page * limit < total,
      has_prev: page > 1,
    },
  };
}

function getRecordById(id) {
  const record = getDb().prepare(`
    SELECT r.*, u.name as created_by_name
    FROM financial_records r
    JOIN users u ON r.created_by = u.id
    WHERE r.id = ? AND r.is_deleted = 0
  `).get(id);
  if (!record) throw new AppError("Record not found", 404);
  return record;
}

function createRecord(data, userId) {
  const db = getDb();
  const id = uuidv4();
  db.prepare(`
    INSERT INTO financial_records (id, amount, type, category, date, notes, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(id, data.amount, data.type, data.category, data.date, data.notes ?? null, userId);
  return getRecordById(id);
}

function updateRecord(id, updates) {
  const db = getDb();
  const record = db.prepare("SELECT id FROM financial_records WHERE id = ? AND is_deleted = 0").get(id);
  if (!record) throw new AppError("Record not found", 404);

  const fields = [];
  const values = [];

  if (updates.amount !== undefined)   { fields.push("amount = ?");   values.push(updates.amount); }
  if (updates.type !== undefined)     { fields.push("type = ?");     values.push(updates.type); }
  if (updates.category !== undefined) { fields.push("category = ?"); values.push(updates.category); }
  if (updates.date !== undefined)     { fields.push("date = ?");     values.push(updates.date); }
  if (updates.notes !== undefined)    { fields.push("notes = ?");    values.push(updates.notes); }

  fields.push("updated_at = datetime('now')");
  values.push(id);

  db.prepare(`UPDATE financial_records SET ${fields.join(", ")} WHERE id = ?`).run(...values);
  return getRecordById(id);
}

function deleteRecord(id) {
  const db = getDb();
  const record = db.prepare("SELECT id FROM financial_records WHERE id = ? AND is_deleted = 0").get(id);
  if (!record) throw new AppError("Record not found", 404);
  // Soft delete
  db.prepare("UPDATE financial_records SET is_deleted = 1, updated_at = datetime('now') WHERE id = ?").run(id);
  return { message: "Record deleted successfully" };
}

module.exports = { listRecords, getRecordById, createRecord, updateRecord, deleteRecord };
