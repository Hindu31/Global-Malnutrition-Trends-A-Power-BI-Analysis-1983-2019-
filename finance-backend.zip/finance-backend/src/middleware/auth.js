const jwt = require("jsonwebtoken");
const { getDb } = require("../config/db");

const JWT_SECRET = process.env.JWT_SECRET || "finance_secret_key_change_in_production";

/**
 * Verifies JWT token and attaches user to req.user
 */
function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid Authorization header" });
  }

  const token = authHeader.slice(7);
  let payload;
  try {
    payload = jwt.verify(token, JWT_SECRET);
  } catch {
    return res.status(401).json({ error: "Token is invalid or expired" });
  }

  const user = getDb()
    .prepare("SELECT id, name, email, role, status FROM users WHERE id = ?")
    .get(payload.userId);

  if (!user) return res.status(401).json({ error: "User not found" });
  if (user.status === "inactive") return res.status(403).json({ error: "Account is inactive" });

  req.user = user;
  next();
}

/**
 * Role hierarchy — higher index = more permissions
 */
const ROLE_LEVEL = { viewer: 0, analyst: 1, admin: 2 };

/**
 * Require at least the given role
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({
        error: `Access denied. Required role: ${roles.join(" or ")}`,
      });
    }
    next();
  };
}

/**
 * Require minimum privilege level
 */
function requireMinRole(minRole) {
  return (req, res, next) => {
    if (ROLE_LEVEL[req.user.role] < ROLE_LEVEL[minRole]) {
      return res.status(403).json({
        error: `Access denied. Minimum required role: ${minRole}`,
      });
    }
    next();
  };
}

function signToken(userId) {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "8h" });
}

module.exports = { authenticate, requireRole, requireMinRole, signToken };
