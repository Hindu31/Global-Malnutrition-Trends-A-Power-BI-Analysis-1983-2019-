const { ZodError } = require("zod");

/**
 * Central error handling middleware — must be registered last.
 */
function errorHandler(err, req, res, next) {
  // Zod validation errors
  if (err instanceof ZodError) {
    return res.status(422).json({
      error: "Validation failed",
      details: err.errors.map((e) => ({
        field: e.path.join("."),
        message: e.message,
      })),
    });
  }

  // Known operational errors
  if (err.isOperational) {
    return res.status(err.statusCode || 400).json({ error: err.message });
  }

  // Unexpected errors — don't leak internals
  console.error("[Unhandled Error]", err);
  return res.status(500).json({ error: "Internal server error" });
}

/**
 * Simple operational error class
 */
class AppError extends Error {
  constructor(message, statusCode = 400) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
  }
}

module.exports = { errorHandler, AppError };
