const express = require("express");
const { authenticate, requireMinRole } = require("../middleware/auth");
const {
  getSummary,
  getCategoryBreakdown,
  getMonthlyTrends,
  getRecentActivity,
  getWeeklyTrends,
} = require("../services/dashboardService");

const router = express.Router();

// All dashboard routes require at least analyst role
router.use(authenticate, requireMinRole("analyst"));

/**
 * GET /api/dashboard/summary
 * Returns total income, expenses, net balance, record count.
 * Optional query params: date_from, date_to (YYYY-MM-DD)
 */
router.get("/summary", (req, res, next) => {
  try {
    const { date_from, date_to } = req.query;
    const data = getSummary({ date_from, date_to });
    res.json({ success: true, data });
  } catch (err) { next(err); }
});

/**
 * GET /api/dashboard/categories
 * Returns per-category totals.
 * Optional: type (income|expense), date_from, date_to
 */
router.get("/categories", (req, res, next) => {
  try {
    const { date_from, date_to, type } = req.query;
    const data = getCategoryBreakdown({ date_from, date_to, type });
    res.json({ success: true, data });
  } catch (err) { next(err); }
});

/**
 * GET /api/dashboard/trends/monthly
 * Monthly income vs expense breakdown.
 * Optional: year (defaults to current year)
 */
router.get("/trends/monthly", (req, res, next) => {
  try {
    const year = req.query.year ? parseInt(req.query.year) : undefined;
    const data = getMonthlyTrends({ year });
    res.json({ success: true, data });
  } catch (err) { next(err); }
});

/**
 * GET /api/dashboard/trends/weekly
 * Last 12 weeks income vs expense.
 */
router.get("/trends/weekly", (req, res, next) => {
  try {
    const data = getWeeklyTrends();
    res.json({ success: true, data });
  } catch (err) { next(err); }
});

/**
 * GET /api/dashboard/recent
 * Most recent financial entries.
 * Optional: limit (default 10, max 50)
 */
router.get("/recent", (req, res, next) => {
  try {
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 10));
    const data = getRecentActivity(limit);
    res.json({ success: true, data });
  } catch (err) { next(err); }
});

module.exports = router;
