const express = require("express");
const { authenticate, requireRole } = require("../middleware/auth");
const {
  listUsers, getUserById, createUser, updateUser, deleteUser,
} = require("../services/userService");
const {
  validate, createUserSchema, updateUserSchema,
} = require("../utils/validators");
const { z } = require("zod");

const router = express.Router();

// All user routes require authentication
router.use(authenticate);

/**
 * GET /api/users
 * Admin only — list all users
 */
router.get("/", requireRole("admin"), (req, res, next) => {
  try {
    const page  = Math.max(1, parseInt(req.query.page)  || 1);
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit) || 20));
    res.json({ success: true, ...listUsers({ page, limit }) });
  } catch (err) { next(err); }
});

/**
 * GET /api/users/:id
 * Admin can see anyone; others can only see themselves
 */
router.get("/:id", (req, res, next) => {
  try {
    if (req.user.role !== "admin" && req.user.id !== req.params.id) {
      return res.status(403).json({ error: "Access denied" });
    }
    res.json({ success: true, data: getUserById(req.params.id) });
  } catch (err) { next(err); }
});

/**
 * POST /api/users
 * Admin only — create a new user
 */
router.post(
  "/",
  requireRole("admin"),
  validate(createUserSchema),
  (req, res, next) => {
    try {
      const user = createUser(req.body);
      res.status(201).json({ success: true, data: user });
    } catch (err) { next(err); }
  }
);

/**
 * PATCH /api/users/:id
 * Admin only — update role/status/name
 */
router.patch(
  "/:id",
  requireRole("admin"),
  validate(updateUserSchema),
  (req, res, next) => {
    try {
      const user = updateUser(req.params.id, req.body);
      res.json({ success: true, data: user });
    } catch (err) { next(err); }
  }
);

/**
 * DELETE /api/users/:id
 * Admin only — permanently delete user
 */
router.delete("/:id", requireRole("admin"), (req, res, next) => {
  try {
    const result = deleteUser(req.params.id, req.user.id);
    res.json({ success: true, ...result });
  } catch (err) { next(err); }
});

module.exports = router;
