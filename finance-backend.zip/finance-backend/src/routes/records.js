const express = require("express");
const { authenticate, requireRole } = require("../middleware/auth");
const {
  listRecords, getRecordById, createRecord, updateRecord, deleteRecord,
} = require("../services/recordService");
const {
  validate, createRecordSchema, updateRecordSchema, recordFilterSchema,
} = require("../utils/validators");

const router = express.Router();

// All record routes require authentication
router.use(authenticate);

/**
 * GET /api/records
 * All authenticated roles — list records with filtering & pagination
 */
router.get("/", validate(recordFilterSchema, "query"), (req, res, next) => {
  try {
    res.json({ success: true, ...listRecords(req.query) });
  } catch (err) { next(err); }
});

/**
 * GET /api/records/:id
 * All authenticated roles — get single record
 */
router.get("/:id", (req, res, next) => {
  try {
    res.json({ success: true, data: getRecordById(req.params.id) });
  } catch (err) { next(err); }
});

/**
 * POST /api/records
 * Admin and Analyst only — create a record
 */
router.post(
  "/",
  requireRole("admin", "analyst"),
  validate(createRecordSchema),
  (req, res, next) => {
    try {
      const record = createRecord(req.body, req.user.id);
      res.status(201).json({ success: true, data: record });
    } catch (err) { next(err); }
  }
);

/**
 * PATCH /api/records/:id
 * Admin only — update a record
 */
router.patch(
  "/:id",
  requireRole("admin"),
  validate(updateRecordSchema),
  (req, res, next) => {
    try {
      const record = updateRecord(req.params.id, req.body);
      res.json({ success: true, data: record });
    } catch (err) { next(err); }
  }
);

/**
 * DELETE /api/records/:id
 * Admin only — soft delete a record
 */
router.delete("/:id", requireRole("admin"), (req, res, next) => {
  try {
    const result = deleteRecord(req.params.id);
    res.json({ success: true, ...result });
  } catch (err) { next(err); }
});

module.exports = router;
