const express = require("express");
const { login } = require("../services/authService");
const { validate, loginSchema } = require("../utils/validators");
const { authenticate } = require("../middleware/auth");

const router = express.Router();

/**
 * POST /api/auth/login
 * Public — returns JWT token
 */
router.post("/login", validate(loginSchema), (req, res, next) => {
  try {
    const result = login(req.body);
    res.json({ success: true, data: result });
  } catch (err) {
    next(err);
  }
});

/**
 * GET /api/auth/me
 * Protected — returns current user's profile
 */
router.get("/me", authenticate, (req, res) => {
  res.json({ success: true, data: req.user });
});

module.exports = router;
