/**
 * Returns { data, pagination } with metadata for paginated responses.
 */
function paginate(db, query, countQuery, params, page, limit) {
  const offset = (page - 1) * limit;
  const total = db.prepare(countQuery).get(params).total;
  const data = db.prepare(`${query} LIMIT ? OFFSET ?`).all(...Object.values(params), limit, offset);

  return {
    data,
    pagination: {
      total,
      page,
      limit,
      total_pages: Math.ceil(total / limit),
      has_next: page * limit < total,
      has_prev: page > 1,
    },
  };
}

module.exports = { paginate };
