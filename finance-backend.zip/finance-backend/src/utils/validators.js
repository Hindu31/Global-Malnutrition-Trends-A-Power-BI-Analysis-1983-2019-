const { z } = require("zod");

// ── Auth ──────────────────────────────────────────────────────────────────────
const loginSchema = z.object({
  email:    z.string().email("Invalid email"),
  password: z.string().min(1, "Password required"),
});

// ── Users ─────────────────────────────────────────────────────────────────────
const createUserSchema = z.object({
  name:     z.string().min(2, "Name must be at least 2 characters"),
  email:    z.string().email("Invalid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  role:     z.enum(["viewer", "analyst", "admin"]).default("viewer"),
});

const updateUserSchema = z.object({
  name:   z.string().min(2).optional(),
  role:   z.enum(["viewer", "analyst", "admin"]).optional(),
  status: z.enum(["active", "inactive"]).optional(),
}).refine(data => Object.keys(data).length > 0, { message: "At least one field required" });

// ── Financial Records ─────────────────────────────────────────────────────────
const createRecordSchema = z.object({
  amount:   z.number().positive("Amount must be positive"),
  type:     z.enum(["income", "expense"]),
  category: z.string().min(1, "Category required").max(100),
  date:     z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be YYYY-MM-DD"),
  notes:    z.string().max(500).optional(),
});

const updateRecordSchema = z.object({
  amount:   z.number().positive().optional(),
  type:     z.enum(["income", "expense"]).optional(),
  category: z.string().min(1).max(100).optional(),
  date:     z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  notes:    z.string().max(500).nullable().optional(),
}).refine(data => Object.keys(data).length > 0, { message: "At least one field required" });

const recordFilterSchema = z.object({
  type:       z.enum(["income", "expense"]).optional(),
  category:   z.string().optional(),
  date_from:  z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  date_to:    z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  page:       z.coerce.number().int().positive().default(1),
  limit:      z.coerce.number().int().min(1).max(100).default(20),
  sort_by:    z.enum(["date", "amount", "created_at"]).default("date"),
  sort_order: z.enum(["asc", "desc"]).default("desc"),
});

/**
 * Middleware factory — parses and validates the request body using the given schema.
 */
function validate(schema, source = "body") {
  return (req, res, next) => {
    try {
      const data = schema.parse(source === "body" ? req.body : req.query);
      if (source === "body") req.body = data;
      else req.query = data;
      next();
    } catch (err) {
      next(err); // passes ZodError to errorHandler
    }
  };
}

module.exports = {
  loginSchema,
  createUserSchema,
  updateUserSchema,
  createRecordSchema,
  updateRecordSchema,
  recordFilterSchema,
  validate,
};
