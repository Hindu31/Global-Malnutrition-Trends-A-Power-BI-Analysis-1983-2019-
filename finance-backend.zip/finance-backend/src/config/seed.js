const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");
const { getDb } = require("./db");

const defaultUsers = [
  { name: "Super Admin",    email: "admin@finance.com",   password: "Admin@123",   role: "admin"    },
  { name: "Alice Analyst",  email: "analyst@finance.com", password: "Analyst@123", role: "analyst"  },
  { name: "Victor Viewer",  email: "viewer@finance.com",  password: "Viewer@123",  role: "viewer"   },
];

const sampleRecords = [
  { amount: 50000, type: "income",  category: "Salary",       date: "2025-03-01", notes: "Monthly salary" },
  { amount: 2000,  type: "expense", category: "Utilities",    date: "2025-03-05", notes: "Electricity bill" },
  { amount: 1500,  type: "expense", category: "Food",         date: "2025-03-10", notes: "Groceries" },
  { amount: 8000,  type: "income",  category: "Freelance",    date: "2025-03-15", notes: "Web project" },
  { amount: 3000,  type: "expense", category: "Rent",         date: "2025-03-20", notes: "Monthly rent" },
  { amount: 500,   type: "expense", category: "Transport",    date: "2025-03-22", notes: "Fuel" },
  { amount: 12000, type: "income",  category: "Investment",   date: "2025-04-01", notes: "Dividend" },
  { amount: 4000,  type: "expense", category: "Healthcare",   date: "2025-04-03", notes: "Hospital" },
  { amount: 700,   type: "expense", category: "Entertainment",date: "2025-04-10", notes: "Movies & dining" },
  { amount: 45000, type: "income",  category: "Salary",       date: "2025-04-01", notes: "Monthly salary" },
];

async function seed() {
  const db = getDb();
  console.log("🌱 Seeding database...");

  let adminId;
  for (const user of defaultUsers) {
    const exists = db.prepare("SELECT id FROM users WHERE email = ?").get(user.email);
    if (!exists) {
      const id = uuidv4();
      const hash = bcrypt.hashSync(user.password, 10);
      db.prepare(`
        INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, ?)
      `).run(id, user.name, user.email, hash, user.role);
      console.log(`  ✅ Created user: ${user.email} (${user.role})`);
      if (user.role === "admin") adminId = id;
    } else {
      console.log(`  ⏭️  User already exists: ${user.email}`);
      if (user.role === "admin") adminId = exists.id;
    }
  }

  const recordCount = db.prepare("SELECT COUNT(*) as c FROM financial_records").get().c;
  if (recordCount === 0 && adminId) {
    const insert = db.prepare(`
      INSERT INTO financial_records (id, amount, type, category, date, notes, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    for (const r of sampleRecords) {
      insert.run(uuidv4(), r.amount, r.type, r.category, r.date, r.notes, adminId);
    }
    console.log(`  ✅ Inserted ${sampleRecords.length} sample records`);
  }

  console.log("✅ Seeding complete!\n");
  console.log("Default credentials:");
  defaultUsers.forEach(u => console.log(`  ${u.role.padEnd(8)} | ${u.email} | ${u.password}`));
}

seed().catch(console.error);
