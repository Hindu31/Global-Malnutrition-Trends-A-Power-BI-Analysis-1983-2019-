const request = require("supertest");
const app = require("../src/app");

// ── Test State ────────────────────────────────────────────────────────────────
let adminToken, analystToken, viewerToken;
let createdRecordId;

// ── Auth Tests ────────────────────────────────────────────────────────────────
describe("POST /api/auth/login", () => {
  it("returns token for valid admin credentials", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "admin@finance.com", password: "Admin@123" });
    expect(res.status).toBe(200);
    expect(res.body.data.token).toBeDefined();
    adminToken = res.body.data.token;
  });

  it("returns token for analyst", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "analyst@finance.com", password: "Analyst@123" });
    expect(res.status).toBe(200);
    analystToken = res.body.data.token;
  });

  it("returns token for viewer", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "viewer@finance.com", password: "Viewer@123" });
    expect(res.status).toBe(200);
    viewerToken = res.body.data.token;
  });

  it("rejects invalid credentials", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "admin@finance.com", password: "wrongpassword" });
    expect(res.status).toBe(401);
  });

  it("rejects missing fields", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({ email: "admin@finance.com" });
    expect(res.status).toBe(422);
  });
});

// ── Records Tests ─────────────────────────────────────────────────────────────
describe("Financial Records", () => {
  it("viewer can list records", async () => {
    const res = await request(app)
      .get("/api/records")
      .set("Authorization", `Bearer ${viewerToken}`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.data)).toBe(true);
  });

  it("analyst can create a record", async () => {
    const res = await request(app)
      .post("/api/records")
      .set("Authorization", `Bearer ${analystToken}`)
      .send({ amount: 1000, type: "income", category: "Test", date: "2025-05-01", notes: "Test record" });
    expect(res.status).toBe(201);
    createdRecordId = res.body.data.id;
  });

  it("viewer cannot create a record", async () => {
    const res = await request(app)
      .post("/api/records")
      .set("Authorization", `Bearer ${viewerToken}`)
      .send({ amount: 500, type: "expense", category: "Test", date: "2025-05-01" });
    expect(res.status).toBe(403);
  });

  it("rejects invalid amount", async () => {
    const res = await request(app)
      .post("/api/records")
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ amount: -100, type: "income", category: "Test", date: "2025-05-01" });
    expect(res.status).toBe(422);
  });

  it("admin can update a record", async () => {
    const res = await request(app)
      .patch(`/api/records/${createdRecordId}`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ amount: 2000 });
    expect(res.status).toBe(200);
    expect(res.body.data.amount).toBe(2000);
  });

  it("supports filtering by type", async () => {
    const res = await request(app)
      .get("/api/records?type=income")
      .set("Authorization", `Bearer ${viewerToken}`);
    expect(res.status).toBe(200);
    res.body.data.forEach(r => expect(r.type).toBe("income"));
  });

  it("admin can soft-delete a record", async () => {
    const res = await request(app)
      .delete(`/api/records/${createdRecordId}`)
      .set("Authorization", `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
  });
});

// ── Dashboard Tests ───────────────────────────────────────────────────────────
describe("Dashboard APIs", () => {
  it("viewer cannot access dashboard", async () => {
    const res = await request(app)
      .get("/api/dashboard/summary")
      .set("Authorization", `Bearer ${viewerToken}`);
    expect(res.status).toBe(403);
  });

  it("analyst can access summary", async () => {
    const res = await request(app)
      .get("/api/dashboard/summary")
      .set("Authorization", `Bearer ${analystToken}`);
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveProperty("net_balance");
  });

  it("analyst can access category breakdown", async () => {
    const res = await request(app)
      .get("/api/dashboard/categories")
      .set("Authorization", `Bearer ${analystToken}`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.data)).toBe(true);
  });

  it("analyst can access monthly trends", async () => {
    const res = await request(app)
      .get("/api/dashboard/trends/monthly")
      .set("Authorization", `Bearer ${analystToken}`);
    expect(res.status).toBe(200);
  });

  it("analyst can access recent activity", async () => {
    const res = await request(app)
      .get("/api/dashboard/recent")
      .set("Authorization", `Bearer ${analystToken}`);
    expect(res.status).toBe(200);
  });
});

// ── User Management Tests ─────────────────────────────────────────────────────
describe("User Management", () => {
  it("admin can list users", async () => {
    const res = await request(app)
      .get("/api/users")
      .set("Authorization", `Bearer ${adminToken}`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.data)).toBe(true);
  });

  it("viewer cannot list users", async () => {
    const res = await request(app)
      .get("/api/users")
      .set("Authorization", `Bearer ${viewerToken}`);
    expect(res.status).toBe(403);
  });

  it("unauthenticated request is rejected", async () => {
    const res = await request(app).get("/api/users");
    expect(res.status).toBe(401);
  });
});
