const bcrypt = require("bcryptjs");
const { v4: uuidv4 } = require("uuid");

module.exports = async function globalSetup() {
  // Use a separate test database
  process.env.NODE_ENV = "test";

  const path = require("path");
  const fs = require("fs");
  const Database = require("better-sqlite3");

  const dbPath = path.join(__dirname, "../data/test.db");
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });

  // Remove stale test DB
  if (fs.existsSync(dbPath)) fs.unlinkSync(dbPath);

  const db = new Database(dbPath);
  db.pragma("foreign_keys = ON");

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'viewer',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS financial_records (
      id TEXT PRIMARY KEY, amount REAL NOT NULL, type TEXT NOT NULL,
      category TEXT NOT NULL, date TEXT NOT NULL, notes TEXT,
      created_by TEXT NOT NULL REFERENCES users(id),
      is_deleted INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const users = [
    { id: uuidv4(), name: "Admin",   email: "admin@finance.com",   password: "Admin@123",   role: "admin" },
    { id: uuidv4(), name: "Analyst", email: "analyst@finance.com", password: "Analyst@123", role: "analyst" },
    { id: uuidv4(), name: "Viewer",  email: "viewer@finance.com",  password: "Viewer@123",  role: "viewer" },
  ];

  const insertUser = db.prepare(
    "INSERT INTO users (id, name, email, password, role) VALUES (?, ?, ?, ?, ?)"
  );

  let adminId;
  for (const u of users) {
    const hash = bcrypt.hashSync(u.password, 4); // low cost for tests
    insertUser.run(u.id, u.name, u.email, hash, u.role);
    if (u.role === "admin") adminId = u.id;
  }

  const insertRecord = db.prepare(
    "INSERT INTO financial_records (id, amount, type, category, date, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)"
  );

  const samples = [
    { amount: 50000, type: "income",  category: "Salary",    date: "2025-03-01", notes: "Salary" },
    { amount: 2000,  type: "expense", category: "Utilities", date: "2025-03-05", notes: "Bills" },
    { amount: 8000,  type: "income",  category: "Freelance", date: "2025-03-15", notes: "Project" },
    { amount: 1500,  type: "expense", category: "Food",      date: "2025-03-10", notes: "Groceries" },
  ];

  for (const r of samples) {
    insertRecord.run(uuidv4(), r.amount, r.type, r.category, r.date, r.notes, adminId);
  }

  db.close();
};
