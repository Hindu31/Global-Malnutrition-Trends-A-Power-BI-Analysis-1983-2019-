const path = require("path");
const fs = require("fs");

module.exports = async function globalTeardown() {
  const dbPath = path.join(__dirname, "../data/test.db");
  if (fs.existsSync(dbPath)) fs.unlinkSync(dbPath);
};
